#create Bucket withs tags  CLI

aws s3 mb s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption --region us-west-2

#add Tags
aws s3api put-bucket-tagging --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption --tagging 'TagSet=[{Key=username,Value=Krishnaveni},{Key=batch,Value=training-2021},{Key=name,Value=cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption},{Key=environment,Value=develop},{Key=region,Value=us-west-2}]'


#copy File from local to s3 bucket
aws s3 cp NO_Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption/


#copy files from one bucket to other: no_enc to  enc
aws s3 cp s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption/NO_Encrypt.txt  s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption/copied_data_from_NO_Encrypt.txt

#Versioning
aws s3api put-bucket-versioning --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption --versioning-configuration Status=Enabled
aws s3api get-bucket-versioning --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption
aws s3api list-object-versions --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption  --prefix version_sample.txt
aws s3api get-object --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption --key version_sample.txt --version-id null version_sample.txt
