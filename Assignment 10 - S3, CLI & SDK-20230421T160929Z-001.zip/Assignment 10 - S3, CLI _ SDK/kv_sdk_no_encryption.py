#create Bucket withs tags  BOTO3


"""session = boto3.Session(
aws_access_key_id=''
aws_secret_access_key=''
)
s3 = session.resource('s3')
"""

import boto3
sess = boto3.Session(region_name='us-west-2')
s3_client = sess.client('s3')
bucket_name = 'cw-us-west-2-101927567363-training-2021-kv-sdk-aes-no-enc'
s3_location = {
    'LocationConstraint': 'us-west-2'
}
s3_client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=s3_location)

#add Tags
s3_tag = boto3.resource('s3')
bucket_tagging = s3_tag.BucketTagging('cw-us-west-2-101927567363-training-2021-kv-sdk-aes-no-enc')
response = bucket_tagging.put(
    Tagging={
        'TagSet': [
            {
                'Key': 'username',
                'Value': 'Krishnaveni'
            },
            {
                'Key': 'batch',
                'Value': 'training-2021'
            },
            {
                'Key': 'name',
                'Value': 'cw-us-west-2-101927567363-training-2021-kv-sdk-aes-no-enc'
            },
            {
                'Key': 'environment',
                'Value': 'develop'
            },
            {
                'Key': 'region',
                'Value': 'us-west-2'
            },
        ]
    },

)

#copy File from local to s3 bucket
import boto3
s3 = boto3.resource('s3')
s3.meta.client.upload_file('/Users/krishnaveni/Desktop/Krishnaveni/Work/Learning/aws_work/NO_Encrypt.txt', 'cw-us-west-2-101927567363-training-2021-kv-sdk-aes-no-enc', 'NO_Encrypt.txt')



#Copy files from one bucket to other: no_enc to enc
import boto3
s3 = boto3.resource('s3')
copy_source = {
    'Bucket': 'cw-us-west-2-101927567363-training-2021-kv-sdk-aes-no-enc',
    'Key': 'NO_Encrypt.txt'
}
bucket = s3.Bucket('cw-us-west-2-101927567363-training-2021-kv-sdk-aes-encInfo')
bucket.copy(copy_source, 'copied_data_from_NO_Encrypt.txt')