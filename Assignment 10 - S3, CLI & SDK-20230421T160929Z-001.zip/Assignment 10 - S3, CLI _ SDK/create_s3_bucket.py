from airflow import DAG
from airflow.operators.python_operator import PythonOperator, ShortCircuitOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash import BashOperator
from datetime import datetime
import boto3

# AWS credentials
aws_access_key_id = 'AKIASVGMAAL4ZNTQCUS3'
aws_secret_access_key = 'SjBaWR0McoHDvYaGmgTPwsf/ZximL0e/ywaijc74'

#python function for  enc bucket
def _create_s3_bucket():
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )
    s3 = session.resource('s3')

    bucket_name = 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-enc-airflow'
    s3_location = {
        'LocationConstraint': 'us-west-2'
    }
    s3.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=s3_location)

    # Add tags
    s3_tag = s3.BucketTagging(bucket_name)
    response = s3_tag.put(
        Tagging={
            'TagSet': [
                {
                    'Key': 'username',
                    'Value': 'Krishnaveni'
                },
                {
                    'Key': 'batch',
                    'Value': 'training-2021'
                },
                {
                    'Key': 'name',
                    'Value': 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-enc-airflow'
                },
                {
                    'Key': 'environment',
                    'Value': 'develop'
                },
                {
                    'Key': 'region',
                    'Value': 'us-west-2'
                },
            ]
        }
    )

    # Add encryption
    s3_client = session.client('s3')
    response2 = s3_client.put_bucket_encryption(
        Bucket=bucket_name,
        ServerSideEncryptionConfiguration={
            'Rules': [
                {
                    'ApplyServerSideEncryptionByDefault': {
                        'SSEAlgorithm': 'AES256',
                    },
                    'BucketKeyEnabled': True
                },
            ]
        },
    )


#python for non_enc bucket
def _create_s3_bucket_no_enc():
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )
    s3 = session.resource('s3')

    bucket_name = 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow'
    s3_location = {
        'LocationConstraint': 'us-west-2'
    }
    s3.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=s3_location)

    # Add tags
    s3_tag = s3.BucketTagging(bucket_name)
    response = s3_tag.put(
        Tagging={
            'TagSet': [
                {
                    'Key': 'username',
                    'Value': 'Krishnaveni'
                },
                {
                    'Key': 'batch',
                    'Value': 'training-2021'
                },
                {
                    'Key': 'name',
                    'Value': 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow'
                },
                {
                    'Key': 'environment',
                    'Value': 'develop'
                },
                {
                    'Key': 'region',
                    'Value': 'us-west-2'
                },
            ]
        }
    )





def copy_files_bw_buckets():
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )
    s3 = session.resource('s3')

    bucket_name = 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow'
    s3_location = {
        'LocationConstraint': 'us-west-2'
    }
    s3_f = boto3.resource('s3')
    # Copy files from one bucket to another
    copy_source = {
        'Bucket': 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow',
        'Key': 'NO_Encrypt.txt'
    }
    s3_f.meta.client.copy_object(CopySource=copy_source,
                               Bucket='cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-enc-airflow',
                               Key='copied_NO_Encrypt.txt')

    # Copy files from one bucket to another
    copy_source = {
        'Bucket': 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-enc-airflow',
        'Key': 'Encrypt.txt'
    }
    s3_f.meta.client.copy_object(CopySource=copy_source, Bucket='cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow', Key='copied_Encrypt.txt')


def _update_file_to_s3():
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )
    s3 = session.resource('s3')

    bucket_name = 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow'
    s3_location = {
        'LocationConstraint': 'us-west-2'
    }
    s3_f = boto3.resource('s3')
    # Copy file from local to S3 bucket
    s3_f.meta.client.upload_file('dags/Encrypt.txt', 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-enc-airflow', 'Encrypt.txt')
    # Copy file from local to S3 bucket
    s3_f.meta.client.upload_file('dags/NO_Encrypt.txt', 'cw-us-west-2-101927567363-training-2021-kv1-sdk-aes-no-enc-airflow', 'NO_Encrypt.txt')



default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1)
}

# Create a DAG
with DAG("create_s3_bucket_sdk", default_args=default_args,
         schedule_interval="@daily", catchup=False) as dag:

    Start_Task = DummyOperator(task_id="Start_Task")

# Create a PythonOperator
    create_s3_bucket_operator = ShortCircuitOperator(
        task_id='create_s3_bucket_task_encryption',
        python_callable=_create_s3_bucket
    )

    create_s3_bucket_operator_no_enc = ShortCircuitOperator(
        task_id='create_s3_bucket_task_no_encryption',
        python_callable=_create_s3_bucket_no_enc
    )
    update_file_to_s3 = ShortCircuitOperator(
        task_id='update_file_to_s3',
        python_callable=_update_file_to_s3
    )
    copy_files_bw_buckets = ShortCircuitOperator(
        task_id='copy_files_bw_buckets',
        python_callable=copy_files_bw_buckets
    )

#bash operators:

    create_bucket_no_enc = BashOperator(
        task_id='create_bucket_no_enc',
        bash_command="aws s3 mb s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow --region us-west-2  \
         && aws s3api put-bucket-tagging --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow \
         --tagging 'TagSet=[{Key=username,Value=Krishnaveni},{Key=batch,Value=training-2021},{Key=name,Value=cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow},{Key=environment,Value=develop},{Key=region,Value=us-west-2}]'  \
         &&  aws s3api put-bucket-versioning --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow --versioning-configuration Status=Enabled"
    )

    create_bucket_enc = BashOperator(
        task_id='create_bucket_enc',
        bash_command="aws s3 mb s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow --region us-west-2  \
        &&  aws s3api put-bucket-tagging --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow  \
        --tagging 'TagSet=[{Key=username,Value=Krishnaveni},{Key=batch,Value=training-2021},{Key=name,Value=cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow},{Key=environment,Value=develop},{Key=region,Value=us-west-2}]'   &&  \
        aws s3api put-bucket-encryption \
        --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow \
        --server-side-encryption-configuration '{'Rules': [{'ApplyServerSideEncryptionByDefault': {'SSEAlgorithm': 'AES256'}}]}'     "
    )

    copy_file_to_s3_bucket = BashOperator(
        task_id='copy_file_to_s3_bucket',
        bash_command='aws s3 cp dags/NO_Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow/  && \
                      aws s3 cp dags/Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow/ '
    )

    copy_files_between_buckets_no_enc = BashOperator(
        task_id='copy_files_between_buckets_no_enc',
        bash_command='s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow/Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow/copied_data_from_Encrypt.txt'
    )
    #
    copy_files_between_buckets_enc = BashOperator(
        task_id='copy_files_between_buckets_enc',
        bash_command='aws s3 cp s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow/NO_Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow/copied_data_from_no_Encrypt.txt'
    )

    end_task = DummyOperator(task_id="end_task")

Start_Task >> create_bucket_no_enc >> copy_file_to_s3_bucket >> copy_files_between_buckets_no_enc >> end_task
Start_Task >> create_bucket_enc >> copy_file_to_s3_bucket >> copy_files_between_buckets_enc >> end_task
Start_Task >> create_s3_bucket_operator >> update_file_to_s3 >> copy_files_bw_buckets >> end_task
Start_Task >> create_s3_bucket_operator_no_enc >> update_file_to_s3 >> copy_files_bw_buckets >>end_task
