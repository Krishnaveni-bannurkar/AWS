#create Bucket withs tags and enc  CLI
aws s3 mb s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption --region us-west-2
#add Tags
aws s3api put-bucket-tagging --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption --tagging 'TagSet=[{Key=username,Value=Krishnaveni},{Key=batch,Value=training-2021},{Key=name,Value=cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption},{Key=environment,Value=develop},{Key=region,Value=us-west-2}]'

#Add encryption
aws s3api put-bucket-encryption \
    --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption \
    --server-side-encryption-configuration '{"Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]}'

#copy File from local to s3 bucket
aws s3 cp Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption/

#copy files from one bucket to other: enc to no enc
aws s3 cp s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption/Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption/copied_data_from_Encrypt.txt


    create_bucket_enc = BashOperator(
        task_id='create_bucket',
        bash_command="aws s3 mb s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow --region us-west-2  \
            &&  aws s3api put-bucket-tagging --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow  \
            --tagging 'TagSet=[{Key=username,Value=Krishnaveni},{Key=batch,Value=training-2021},{Key=name,Value=cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow},{Key=environment,Value=develop},{Key=region,Value=us-west-2}]'   &&  \
            aws s3api put-bucket-encryption \
            --bucket cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption \
            --server-side-encryption-configuration '{'Rules': [{'ApplyServerSideEncryptionByDefault': {'SSEAlgorithm': 'AES256'}}]}'     ",
        dag=dag
    )

    copy_files_between_buckets_no-enc = BashOperator(
        task_id='copy_files_between_buckets',
        bash_command='aws s3 cp s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-no-encrption_airflow/NO_Encrypt.txt s3://cw-us-west-2-101927567363-training-2021-kv1-cli-aes-encrption_airflow/copied_data_from_no_Encrypt.txt',
        dag=dag
    )
